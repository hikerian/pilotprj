/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.6.2-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: hddbscan
-- ------------------------------------------------------
-- Server version	11.6.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Dumping data for table `ui_page`
--

LOCK TABLES `ui_page` WRITE;
/*!40000 ALTER TABLE `ui_page` DISABLE KEYS */;
INSERT INTO `ui_page` (`page_id`, `page_desc`, `page_nm`) VALUES (1,'교과그룹관리','교과그룹관리'),
(2,'교과목관리','교과목관리'),
(3,'교육과정관리','교육과정관리'),
(4,'교육과정학과신청','교육과정학과신청'),
(5,'대체과목관리','대체과목관리'),
(6,'여석조회','여석조회'),
(7,'진급결과조회','진급결과조회'),
(8,'편입생인정성적관리','편입생인정성적관리'),
(9,'학적변동신청내역조회','학적변동신청내역조회'),
(10,'개설강좌관리','개설강좌관리'),
(11,'사회봉사활동관리','사회봉사활동관리'),
(12,'자치기구활동관리','자치기구활동관리'),
(13,'프로그램관리','프로그램관리');
/*!40000 ALTER TABLE `ui_page` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-05-15 16:12:57
